import 'react-native-gesture-handler';
import React from 'react';
import { Provider as StoreProvider, useSelector } from 'react-redux';
import { PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import store from './src/app/store';
import RootNavigator from './src/navigation/RootNavigator';
import { LightTheme, DarkTheme } from './src/theme/theme';

const AppContent = () => {
  const darkMode = useSelector((s) => s.ui.darkMode);
  const theme = darkMode ? DarkTheme : LightTheme;
  return (
    <PaperProvider theme={theme}>
      <SafeAreaProvider>
        <StatusBar style={darkMode ? 'light' : 'dark'} />
        <RootNavigator />
      </SafeAreaProvider>
    </PaperProvider>
  );
};

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <StoreProvider store={store}>
        <AppContent />
      </StoreProvider>
    </GestureHandlerRootView>
  );
}
