import axiosInstance from './axiosInstance';

export const authAPI = {
  login: (credentials) => axiosInstance.post('/service/users/login', credentials),
  register: (data) => axiosInstance.post('/service/users/register', data),
  logout: () => axiosInstance.post('/service/users/logout'),
  getProfile: () => axiosInstance.get('/service/users/profile'),
  updateProfile: (data) => axiosInstance.put('/service/users/profile', data),
  changePassword: (data) => axiosInstance.put('/service/users/change-password', data),
};
