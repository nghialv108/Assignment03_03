import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const axiosClient = axios.create({
    baseURL: 'http://localhost:3000/service', // Dùng 10.0.2.2 cho máy ảo Android thay vì localhost
    headers: {
        'Content-Type': 'application/json',
    },
});

// Interceptor: Tự động nhét Token vào Header
axiosClient.interceptors.request.use(async (config) => {
    const token = await AsyncStorage.getItem('userToken');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export default axiosClient;