import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';

const BookCard = ({ book }) => {
    return (
        <View style={styles.card}>
            <Text style={styles.title}>{book.title}</Text>
            <Text style={styles.author}>{book.author}</Text>
            <Text style={styles.stock}>Còn lại: {book.available_copies}/{book.total_copies}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    card: {
        backgroundColor: colors.surface,
        padding: 15,
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 8,
    },
    title: { color: colors.text, fontSize: 18, fontWeight: 'bold' },
    author: { color: colors.textSecondary, marginTop: 4 },
    stock: { color: colors.primary, marginTop: 8, fontWeight: 'bold' }
});

export default BookCard;