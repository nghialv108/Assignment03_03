import React from 'react';
import { Button } from 'react-native-paper';

const AppButton = ({ children, style, contentStyle, ...props }) => (
  <Button
    mode="contained"
    style={[{ borderRadius: 12, marginTop: 4 }, style]}
    contentStyle={[{ paddingVertical: 6 }, contentStyle]}
    labelStyle={{ fontSize: 16, fontWeight: '700', letterSpacing: 0.2 }}
    {...props}
  >
    {children}
  </Button>
);

export default AppButton;
