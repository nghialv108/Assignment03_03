import React from 'react';
import { TextInput, HelperText } from 'react-native-paper';
import { useTheme } from 'react-native-paper';

const AppInput = ({ label, error, helperText, style, ...props }) => {
  const theme = useTheme();
  return (
    <>
      <TextInput
        label={label}
        mode="outlined"
        error={!!error}
        style={[{ marginBottom: error || helperText ? 0 : 12, backgroundColor: theme.colors.surface }, style]}
        outlineStyle={{ borderRadius: 12 }}
        {...props}
      />
      {(error || helperText) && (
        <HelperText type={error ? 'error' : 'info'} visible>
          {error || helperText}
        </HelperText>
      )}
    </>
  );
};

export default AppInput;
