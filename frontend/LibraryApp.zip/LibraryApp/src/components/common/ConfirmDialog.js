import React from 'react';
import { Dialog, Portal, Text, Button } from 'react-native-paper';
import { View } from 'react-native';

const ConfirmDialog = ({ visible, title, message, onConfirm, onDismiss, confirmLabel = 'Xác nhận', confirmColor = '#ef4444' }) => (
  <Portal>
    <Dialog visible={visible} onDismiss={onDismiss} style={{ borderRadius: 20 }}>
      <Dialog.Title style={{ fontWeight: '700' }}>{title || 'Xác nhận'}</Dialog.Title>
      <Dialog.Content>
        <Text variant="bodyMedium">{message}</Text>
      </Dialog.Content>
      <Dialog.Actions>
        <Button onPress={onDismiss} textColor="#64748b">Hủy</Button>
        <Button onPress={onConfirm} textColor={confirmColor} labelStyle={{ fontWeight: '700' }}>
          {confirmLabel}
        </Button>
      </Dialog.Actions>
    </Dialog>
  </Portal>
);

export default ConfirmDialog;
