import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Button, useTheme } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';

const EmptyState = ({ icon = 'folder-open-outline', title = 'Không có dữ liệu', description, onAction, actionLabel }) => {
  const theme = useTheme();
  return (
    <View style={styles.container}>
      <Ionicons name={icon} size={64} color={theme.colors.outline} />
      <Text variant="titleMedium" style={[styles.title, { color: theme.colors.onSurfaceVariant }]}>{title}</Text>
      {description && (
        <Text variant="bodySmall" style={[styles.desc, { color: theme.colors.outline }]}>{description}</Text>
      )}
      {onAction && (
        <Button mode="contained" onPress={onAction} style={{ marginTop: 16, borderRadius: 12 }}>
          {actionLabel || 'Thêm mới'}
        </Button>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { alignItems: 'center', paddingVertical: 48, paddingHorizontal: 24 },
  title: { marginTop: 12, fontWeight: '600' },
  desc: { marginTop: 4, textAlign: 'center' },
});

export default EmptyState;
