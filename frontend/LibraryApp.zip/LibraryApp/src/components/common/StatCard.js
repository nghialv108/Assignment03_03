import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Card, useTheme } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';

const StatCard = ({ title, value, icon, color = '#6366f1', trend, trendValue, subtitle }) => {
  const theme = useTheme();
  const isUp = trend === 'up';

  return (
    <Card style={[styles.card, { backgroundColor: theme.colors.surface }]}>
      <Card.Content style={styles.content}>
        <View style={styles.left}>
          <Text variant="labelSmall" style={{ color: theme.colors.onSurfaceVariant, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 4 }}>
            {title}
          </Text>
          <Text variant="headlineMedium" style={{ fontWeight: '800', color: theme.colors.onSurface }}>
            {value}
          </Text>
          {trendValue && (
            <View style={styles.trend}>
              <Ionicons
                name={isUp ? 'trending-up' : 'trending-down'}
                size={14}
                color={isUp ? '#10b981' : '#ef4444'}
              />
              <Text variant="labelSmall" style={{ color: isUp ? '#10b981' : '#ef4444', fontWeight: '700', marginLeft: 2 }}>
                {trendValue}
              </Text>
              {subtitle && (
                <Text variant="labelSmall" style={{ color: theme.colors.onSurfaceVariant, marginLeft: 4 }}>
                  {subtitle}
                </Text>
              )}
            </View>
          )}
        </View>
        <View style={[styles.iconBox, { backgroundColor: color }]}>
          <Ionicons name={icon} size={24} color="#fff" />
        </View>
      </Card.Content>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: { borderRadius: 16, elevation: 2 },
  content: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  left: { flex: 1 },
  trend: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  iconBox: { width: 48, height: 48, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
});

export default StatCard;
