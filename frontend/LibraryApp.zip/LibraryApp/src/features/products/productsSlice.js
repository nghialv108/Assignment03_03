import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { productsAPI } from '../../api/productsAPI';

export const fetchProducts = createAsyncThunk('products/fetchAll', async (params, { rejectWithValue }) => {
  try { return (await productsAPI.getAll(params)).data; }
  catch (err) { return rejectWithValue(err.response?.data?.message || 'Không thể tải sản phẩm'); }
});

export const createProduct = createAsyncThunk('products/create', async (data, { rejectWithValue }) => {
  try { return (await productsAPI.create(data)).data; }
  catch (err) { return rejectWithValue(err.response?.data?.message || 'Tạo thất bại'); }
});

export const updateProduct = createAsyncThunk('products/update', async ({ id, data }, { rejectWithValue }) => {
  try { return (await productsAPI.update(id, data)).data; }
  catch (err) { return rejectWithValue(err.response?.data?.message || 'Cập nhật thất bại'); }
});

export const deleteProduct = createAsyncThunk('products/delete', async (id, { rejectWithValue }) => {
  try { await productsAPI.delete(id); return id; }
  catch (err) { return rejectWithValue(err.response?.data?.message || 'Xóa thất bại'); }
});

const productsSlice = createSlice({
  name: 'products',
  initialState: { list: [], total: 0, loading: false, error: null },
  reducers: { clearError(state) { state.error = null; } },
  extraReducers: (builder) => {
    builder.addCase(fetchProducts.pending, (state) => { state.loading = true; state.error = null; });
    builder.addCase(fetchProducts.fulfilled, (state, action) => {
      state.loading = false;
      state.list = Array.isArray(action.payload) ? action.payload : (action.payload.data || []);
      state.total = action.payload.total || state.list.length;
    });
    builder.addCase(fetchProducts.rejected, (state, action) => { state.loading = false; state.error = action.payload; });
    builder.addCase(createProduct.fulfilled, (state, action) => { state.list.unshift(action.payload); state.total += 1; });
    builder.addCase(updateProduct.fulfilled, (state, action) => {
      const idx = state.list.findIndex((p) => p.id === action.payload.id || p._id === action.payload._id);
      if (idx !== -1) state.list[idx] = action.payload;
    });
    builder.addCase(deleteProduct.fulfilled, (state, action) => {
      state.list = state.list.filter((p) => p.id !== action.payload && p._id !== action.payload);
      state.total -= 1;
    });
  },
});

export const { clearError } = productsSlice.actions;
export default productsSlice.reducer;
