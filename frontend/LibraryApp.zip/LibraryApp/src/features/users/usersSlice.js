import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { usersAPI } from '../../api/usersAPI';

export const fetchUsers = createAsyncThunk('users/fetchAll', async (params, { rejectWithValue }) => {
  try {
    const res = await usersAPI.getAll(params);
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data?.message || 'Không thể tải danh sách');
  }
});

export const createUser = createAsyncThunk('users/create', async (data, { rejectWithValue }) => {
  try { return (await usersAPI.create(data)).data; }
  catch (err) { return rejectWithValue(err.response?.data?.message || 'Tạo thất bại'); }
});

export const updateUser = createAsyncThunk('users/update', async ({ id, data }, { rejectWithValue }) => {
  try { return (await usersAPI.update(id, data)).data; }
  catch (err) { return rejectWithValue(err.response?.data?.message || 'Cập nhật thất bại'); }
});

export const deleteUser = createAsyncThunk('users/delete', async (id, { rejectWithValue }) => {
  try { await usersAPI.delete(id); return id; }
  catch (err) { return rejectWithValue(err.response?.data?.message || 'Xóa thất bại'); }
});

const usersSlice = createSlice({
  name: 'users',
  initialState: { list: [], total: 0, loading: false, error: null },
  reducers: { clearError(state) { state.error = null; } },
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.pending, (state) => { state.loading = true; state.error = null; });
    builder.addCase(fetchUsers.fulfilled, (state, action) => {
      state.loading = false;
      state.list = Array.isArray(action.payload) ? action.payload : (action.payload.data || []);
      state.total = action.payload.total || state.list.length;
    });
    builder.addCase(fetchUsers.rejected, (state, action) => { state.loading = false; state.error = action.payload; });
    builder.addCase(createUser.fulfilled, (state, action) => { state.list.unshift(action.payload); state.total += 1; });
    builder.addCase(updateUser.fulfilled, (state, action) => {
      const idx = state.list.findIndex((u) => u.id === action.payload.id || u._id === action.payload._id);
      if (idx !== -1) state.list[idx] = action.payload;
    });
    builder.addCase(deleteUser.fulfilled, (state, action) => {
      state.list = state.list.filter((u) => u.id !== action.payload && u._id !== action.payload);
      state.total -= 1;
    });
  },
});

export const { clearError } = usersSlice.actions;
export default usersSlice.reducer;
