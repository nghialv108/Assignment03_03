import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDarkMode, toggleDarkMode as toggleAction } from '../features/ui/uiSlice';
import { LightTheme, DarkTheme } from '../theme/theme';

export const useAppTheme = () => {
  const dispatch = useDispatch();
  const darkMode = useSelector((s) => s.ui.darkMode);

  // Restore từ AsyncStorage khi mount
  useEffect(() => {
    AsyncStorage.getItem('darkMode').then((val) => {
      if (val !== null) dispatch(setDarkMode(JSON.parse(val)));
    });
  }, []);

  const toggle = async () => {
    const next = !darkMode;
    dispatch(toggleAction());
    await AsyncStorage.setItem('darkMode', JSON.stringify(next));
  };

  return {
    darkMode,
    toggle,
    theme: darkMode ? DarkTheme : LightTheme,
  };
};
