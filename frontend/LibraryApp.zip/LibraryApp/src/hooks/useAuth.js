import { useDispatch, useSelector } from 'react-redux';
import { login, logout, register, clearError } from '../features/auth/authSlice';

export const useAuth = () => {
  const dispatch = useDispatch();
  const { user, isAuthenticated, loading, error } = useSelector((s) => s.auth);

  return {
    user,
    isAuthenticated,
    loading,
    error,
    login: (creds) => dispatch(login(creds)),
    register: (data) => dispatch(register(data)),
    logout: () => dispatch(logout()),
    clearError: () => dispatch(clearError()),
  };
};
