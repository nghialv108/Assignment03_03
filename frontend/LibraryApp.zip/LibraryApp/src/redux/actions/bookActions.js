import axiosClient from '../../api/axiosClient';

export const fetchBooks = () => {
    return async (dispatch) => {
        dispatch({ type: 'FETCH_BOOKS_REQUEST' });
        try {
            const response = await axiosClient.get('/books');
            dispatch({ type: 'FETCH_BOOKS_SUCCESS', payload: response.data });
        } catch (error) {
            dispatch({ type: 'FETCH_BOOKS_FAILURE', payload: error.message });
        }
    };
};