import { createStore, combineReducers, applyMiddleware } from 'redux';
import { thunk } from 'redux-thunk';
import bookReducer from './reducers/bookReducer';

// Gom tất cả reducers (nếu có userReducer, categoryReducer thì thêm vào đây)
const rootReducer = combineReducers({
    book: bookReducer,
});

export const store = createStore(rootReducer, applyMiddleware(thunk));