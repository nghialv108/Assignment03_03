import React, { useEffect } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchBooks } from '../redux/actions/bookActions';
import BookCard from '../components/BookCard';
import { colors } from '../theme/colors';

const HomeScreen = () => {
    const dispatch = useDispatch();
    const { books, loading, error } = useSelector((state) => state.book);

    useEffect(() => {
        dispatch(fetchBooks());
    }, [dispatch]);

    if (loading) return <ActivityIndicator size="large" color={colors.primary} style={styles.loader} />;
    if (error) return <Text style={styles.errorText}>Lỗi: {error}</Text>;

    return (
        <View style={styles.container}>
            <Text style={styles.headerTitle}>Thư viện của bạn</Text>
            <FlatList
                data={books}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => <BookCard book={item} />}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background, paddingTop: 20 },
    loader: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    errorText: { color: colors.danger, textAlign: 'center', marginTop: 20 },
    headerTitle: { color: colors.text, fontSize: 24, fontWeight: 'bold', marginLeft: 16, marginBottom: 10 }
});

export default HomeScreen;