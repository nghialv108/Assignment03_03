import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';

const ProfileScreen = () => (
    <View style={styles.container}>
        <Text style={styles.text}>Màn hình Cá nhân</Text>
    </View>
);

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' },
    text: { color: colors.text, fontSize: 20 }
});

export default ProfileScreen;