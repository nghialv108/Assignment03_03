import React, { useState, useEffect } from 'react';
import {
  View, ScrollView, StyleSheet, KeyboardAvoidingView, Platform, TouchableOpacity,
} from 'react-native';
import { Text, Surface, useTheme, Snackbar } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../hooks/useAuth';
import AppInput from '../../components/common/AppInput';
import AppButton from '../../components/common/AppButton';

const LoginScreen = ({ navigation }) => {
  const theme = useTheme();
  const { login, loading, error, clearError, isAuthenticated } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [snackVisible, setSnackVisible] = useState(false);

  useEffect(() => {
    if (error) setSnackVisible(true);
  }, [error]);

  const handleLogin = async () => {
    if (!email || !password) return;
    await login({ email, password });
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        contentContainerStyle={[styles.container, { backgroundColor: theme.colors.background }]}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header gradient */}
        <View style={styles.header}>
          <View style={[styles.logoBox, { backgroundColor: theme.colors.primary }]}>
            <Ionicons name="shield-checkmark" size={36} color="#fff" />
          </View>
          <Text variant="headlineMedium" style={[styles.title, { color: theme.colors.onSurface }]}>
            Đăng nhập
          </Text>
          <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant, textAlign: 'center' }}>
            Chào mừng trở lại! Đăng nhập để tiếp tục.
          </Text>
        </View>

        {/* Form */}
        <Surface style={[styles.form, { backgroundColor: theme.colors.surface }]} elevation={2}>
          <AppInput
            label="Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
            left={<AppInput.Icon icon="email-outline" />}
          />
          <AppInput
            label="Mật khẩu"
            value={password}
            onChangeText={setPassword}
            secureTextEntry={!showPassword}
            left={<AppInput.Icon icon="lock-outline" />}
            right={
              <AppInput.Icon
                icon={showPassword ? 'eye-off' : 'eye'}
                onPress={() => setShowPassword(!showPassword)}
              />
            }
          />

          <AppButton
            onPress={handleLogin}
            loading={loading}
            disabled={loading || !email || !password}
            style={{ marginTop: 8 }}
          >
            Đăng nhập
          </AppButton>

          <TouchableOpacity
            onPress={() => navigation.navigate('Register')}
            style={styles.registerLink}
          >
            <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>
              Chưa có tài khoản?{' '}
              <Text style={{ color: theme.colors.primary, fontWeight: '700' }}>Đăng ký ngay</Text>
            </Text>
          </TouchableOpacity>
        </Surface>

        <Snackbar
          visible={snackVisible}
          onDismiss={() => { setSnackVisible(false); clearError(); }}
          duration={3000}
          action={{ label: 'Đóng', onPress: () => { setSnackVisible(false); clearError(); } }}
        >
          {error}
        </Snackbar>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 24, justifyContent: 'center' },
  header: { alignItems: 'center', marginBottom: 32 },
  logoBox: {
    width: 72, height: 72, borderRadius: 20,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#6366f1', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.3, shadowRadius: 16,
    elevation: 8,
  },
  title: { fontWeight: '800', marginBottom: 8 },
  form: { borderRadius: 24, padding: 24, gap: 4 },
  registerLink: { marginTop: 16, alignItems: 'center' },
});

export default LoginScreen;
