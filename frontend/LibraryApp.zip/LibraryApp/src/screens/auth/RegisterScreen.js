import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, KeyboardAvoidingView, Platform, TouchableOpacity } from 'react-native';
import { Text, Surface, useTheme, Snackbar } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../hooks/useAuth';
import AppInput from '../../components/common/AppInput';
import AppButton from '../../components/common/AppButton';

const RegisterScreen = ({ navigation }) => {
  const theme = useTheme();
  const { register, loading, error, clearError } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [snackVisible, setSnackVisible] = useState(false);
  const [localError, setLocalError] = useState('');

  useEffect(() => { if (error) setSnackVisible(true); }, [error]);

  const set = (key) => (val) => setForm((p) => ({ ...p, [key]: val }));

  const handleRegister = async () => {
    if (form.password !== form.confirmPassword) {
      setLocalError('Mật khẩu xác nhận không khớp');
      setSnackVisible(true);
      return;
    }
    const { confirmPassword, ...data } = form;
    await register(data);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={[styles.container, { backgroundColor: theme.colors.background }]} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <View style={[styles.logoBox, { backgroundColor: '#f43f5e' }]}>
            <Ionicons name="person-add" size={32} color="#fff" />
          </View>
          <Text variant="headlineMedium" style={[styles.title, { color: theme.colors.onSurface }]}>Đăng ký</Text>
          <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant, textAlign: 'center' }}>
            Tạo tài khoản mới để bắt đầu
          </Text>
        </View>

        <Surface style={[styles.form, { backgroundColor: theme.colors.surface }]} elevation={2}>
          <AppInput label="Họ và tên" value={form.name} onChangeText={set('name')} left={<AppInput.Icon icon="account-outline" />} />
          <AppInput label="Email" value={form.email} onChangeText={set('email')} keyboardType="email-address" autoCapitalize="none" left={<AppInput.Icon icon="email-outline" />} />
          <AppInput
            label="Mật khẩu" value={form.password} onChangeText={set('password')} secureTextEntry={!showPassword}
            left={<AppInput.Icon icon="lock-outline" />}
            right={<AppInput.Icon icon={showPassword ? 'eye-off' : 'eye'} onPress={() => setShowPassword(!showPassword)} />}
          />
          <AppInput
            label="Xác nhận mật khẩu" value={form.confirmPassword} onChangeText={set('confirmPassword')} secureTextEntry={!showPassword}
            left={<AppInput.Icon icon="lock-check-outline" />}
          />

          <AppButton
            onPress={handleRegister} loading={loading} disabled={loading}
            style={{ marginTop: 8, backgroundColor: '#f43f5e' }}
          >
            Đăng ký
          </AppButton>

          <TouchableOpacity onPress={() => navigation.navigate('Login')} style={styles.loginLink}>
            <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>
              Đã có tài khoản?{' '}
              <Text style={{ color: theme.colors.primary, fontWeight: '700' }}>Đăng nhập</Text>
            </Text>
          </TouchableOpacity>
        </Surface>

        <Snackbar
          visible={snackVisible}
          onDismiss={() => { setSnackVisible(false); clearError(); setLocalError(''); }}
          duration={3000}
        >
          {error || localError}
        </Snackbar>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 24, justifyContent: 'center' },
  header: { alignItems: 'center', marginBottom: 32 },
  logoBox: { width: 72, height: 72, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginBottom: 20, elevation: 8 },
  title: { fontWeight: '800', marginBottom: 8 },
  form: { borderRadius: 24, padding: 24, gap: 4 },
  loginLink: { marginTop: 16, alignItems: 'center' },
});

export default RegisterScreen;
