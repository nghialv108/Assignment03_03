import React, { useEffect } from 'react';
import { ScrollView, View, StyleSheet, RefreshControl } from 'react-native';
import { Text, Card, Chip, useTheme, Avatar } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers } from '../../features/users/usersSlice';
import { fetchProducts } from '../../features/products/productsSlice';
import StatCard from '../../components/common/StatCard';

const ACTIVITIES = [
  { text: 'Người dùng mới đăng ký', time: '5 phút trước', color: '#6366f1' },
  { text: 'Sản phẩm mới được thêm', time: '12 phút trước', color: '#10b981' },
  { text: 'Đơn hàng #1042 hoàn thành', time: '1 giờ trước', color: '#3b82f6' },
  { text: 'Cập nhật hệ thống', time: '3 giờ trước', color: '#f59e0b' },
];

const DashboardScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const { total: totalUsers, loading: usersLoading } = useSelector((s) => s.users);
  const { total: totalProducts, loading: productsLoading } = useSelector((s) => s.products);
  const { user } = useSelector((s) => s.auth);
  const refreshing = usersLoading || productsLoading;

  const load = () => {
    dispatch(fetchUsers());
    dispatch(fetchProducts());
  };

  useEffect(() => { load(); }, []);

  return (
    <ScrollView
      style={{ backgroundColor: theme.colors.background }}
      contentContainerStyle={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} colors={[theme.colors.primary]} />}
    >
      {/* Welcome */}
      <View style={styles.welcome}>
        <Text variant="headlineSmall" style={{ fontWeight: '800', color: theme.colors.onSurface }}>
          Xin chào, {user?.name || 'Admin'} 👋
        </Text>
        <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant, marginTop: 2 }}>
          Đây là tổng quan hệ thống hôm nay
        </Text>
      </View>

      {/* Stats Grid */}
      <View style={styles.statsGrid}>
        <View style={styles.statRow}>
          <View style={styles.statHalf}>
            <StatCard title="Người dùng" value={totalUsers || '—'} icon="people" color="#6366f1" trend="up" trendValue="+12%" />
          </View>
          <View style={styles.statHalf}>
            <StatCard title="Sản phẩm" value={totalProducts || '—'} icon="cube" color="#10b981" trend="up" trendValue="+5%" />
          </View>
        </View>
        <View style={styles.statRow}>
          <View style={styles.statHalf}>
            <StatCard title="Doanh thu" value="₫48.2M" icon="cash" color="#f59e0b" trend="down" trendValue="-3%" />
          </View>
          <View style={styles.statHalf}>
            <StatCard title="Tăng trưởng" value="24.8%" icon="trending-up" color="#f43f5e" trend="up" trendValue="+8%" />
          </View>
        </View>
      </View>

      {/* Progress bars */}
      <Card style={[styles.card, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text variant="titleMedium" style={{ fontWeight: '700', marginBottom: 16 }}>Thống kê nhanh</Text>
          {[
            { label: 'Người dùng hoạt động', value: 89, color: '#6366f1' },
            { label: 'Tỷ lệ hoàn thành đơn', value: 94, color: '#10b981' },
            { label: 'Sản phẩm còn hàng', value: 76, color: '#f59e0b' },
            { label: 'Hài lòng khách hàng', value: 98, color: '#f43f5e' },
          ].map((item, i) => (
            <View key={i} style={{ marginBottom: i < 3 ? 16 : 0 }}>
              <View style={styles.progressHeader}>
                <Text variant="bodySmall" style={{ color: theme.colors.onSurfaceVariant }}>{item.label}</Text>
                <Text variant="bodySmall" style={{ fontWeight: '700', color: theme.colors.onSurface }}>{item.value}%</Text>
              </View>
              <View style={[styles.progressBg, { backgroundColor: theme.colors.surfaceVariant }]}>
                <View style={[styles.progressFill, { width: `${item.value}%`, backgroundColor: item.color }]} />
              </View>
            </View>
          ))}
        </Card.Content>
      </Card>

      {/* Recent Activity */}
      <Card style={[styles.card, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text variant="titleMedium" style={{ fontWeight: '700', marginBottom: 16 }}>Hoạt động gần đây</Text>
          {ACTIVITIES.map((item, i) => (
            <View key={i} style={[styles.activityItem, i < ACTIVITIES.length - 1 && { marginBottom: 14 }]}>
              <View style={[styles.activityDot, { backgroundColor: item.color }]} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text variant="bodyMedium" style={{ fontWeight: '500', color: theme.colors.onSurface }}>{item.text}</Text>
                <Text variant="labelSmall" style={{ color: theme.colors.onSurfaceVariant, marginTop: 2 }}>{item.time}</Text>
              </View>
            </View>
          ))}
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, paddingBottom: 32 },
  welcome: { marginBottom: 20 },
  statsGrid: { gap: 12, marginBottom: 16 },
  statRow: { flexDirection: 'row', gap: 12 },
  statHalf: { flex: 1 },
  card: { borderRadius: 16, marginBottom: 16, elevation: 1 },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  progressBg: { height: 6, borderRadius: 3 },
  progressFill: { height: '100%', borderRadius: 3 },
  activityItem: { flexDirection: 'row', alignItems: 'flex-start' },
  activityDot: { width: 8, height: 8, borderRadius: 4, marginTop: 5 },
});

export default DashboardScreen;
