import React, { useEffect, useState, useCallback } from 'react';
import { View, FlatList, StyleSheet, RefreshControl } from 'react-native';
import {
  Text, Searchbar, FAB, Card, Chip, IconButton, useTheme,
  ActivityIndicator, Portal, Modal, TextInput, Button, Snackbar,
} from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts, createProduct, updateProduct, deleteProduct } from '../../features/products/productsSlice';
import { useDebounce } from '../../hooks/useDebounce';
import EmptyState from '../../components/common/EmptyState';
import ConfirmDialog from '../../components/common/ConfirmDialog';

const CATEGORIES = ['Điện tử', 'Thời trang', 'Gia dụng', 'Thực phẩm', 'Khác'];

const defaultForm = { name: '', description: '', price: '', stock: '', category: 'Khác' };

const ProductFormModal = ({ visible, onDismiss, onSubmit, initial, loading }) => {
  const theme = useTheme();
  const isEdit = !!initial;
  const [form, setForm] = useState(defaultForm);

  useEffect(() => {
    setForm(initial
      ? { name: initial.name || '', description: initial.description || '', price: String(initial.price ?? ''), stock: String(initial.stock ?? ''), category: initial.category || 'Khác' }
      : defaultForm
    );
  }, [initial, visible]);

  const set = (k) => (v) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={[styles.modal, { backgroundColor: theme.colors.surface }]}>
        <Text variant="titleLarge" style={{ fontWeight: '700', marginBottom: 16 }}>
          {isEdit ? 'Cập nhật sản phẩm' : 'Thêm sản phẩm'}
        </Text>

        <TextInput label="Tên sản phẩm" value={form.name} onChangeText={set('name')} mode="outlined" style={styles.input} />
        <TextInput label="Mô tả" value={form.description} onChangeText={set('description')} mode="outlined" multiline numberOfLines={3} style={styles.input} />
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <TextInput label="Giá (₫)" value={form.price} onChangeText={set('price')} mode="outlined" keyboardType="numeric" style={[styles.input, { flex: 1 }]} />
          <TextInput label="Tồn kho" value={form.stock} onChangeText={set('stock')} mode="outlined" keyboardType="numeric" style={[styles.input, { flex: 1 }]} />
        </View>

        <Text variant="labelMedium" style={{ color: theme.colors.onSurfaceVariant, marginBottom: 6 }}>Danh mục</Text>
        <View style={styles.catRow}>
          {CATEGORIES.map((c) => (
            <Chip key={c} selected={form.category === c} onPress={() => set('category')(c)} compact style={styles.catChip}>
              {c}
            </Chip>
          ))}
        </View>

        <View style={styles.modalActions}>
          <Button onPress={onDismiss} textColor={theme.colors.onSurfaceVariant} style={{ flex: 1 }}>Hủy</Button>
          <Button mode="contained" onPress={() => onSubmit({ ...form, price: Number(form.price), stock: Number(form.stock) })} loading={loading} style={{ flex: 1, borderRadius: 12 }}>
            {isEdit ? 'Cập nhật' : 'Thêm mới'}
          </Button>
        </View>
      </Modal>
    </Portal>
  );
};

const ProductCard = ({ product, onEdit, onDelete }) => {
  const theme = useTheme();
  const isLow = product.stock <= 5;

  return (
    <Card style={[styles.productCard, { backgroundColor: theme.colors.surface }]}>
      <Card.Content>
        <View style={styles.productHeader}>
          <View style={[styles.productIcon, { backgroundColor: theme.colors.surfaceVariant }]}>
            <Ionicons name="cube-outline" size={28} color={theme.colors.primary} />
          </View>
          <View style={styles.productActions}>
            <IconButton icon="pencil" size={18} iconColor={theme.colors.primary} onPress={() => onEdit(product)} />
            <IconButton icon="delete" size={18} iconColor="#ef4444" onPress={() => onDelete(product)} />
          </View>
        </View>

        <Text variant="titleSmall" style={{ fontWeight: '700', color: theme.colors.onSurface, marginTop: 8 }} numberOfLines={1}>
          {product.name}
        </Text>
        <Text variant="bodySmall" style={{ color: theme.colors.onSurfaceVariant, marginTop: 2 }} numberOfLines={2}>
          {product.description || 'Không có mô tả'}
        </Text>

        <View style={styles.productFooter}>
          <Text variant="titleMedium" style={{ fontWeight: '800', color: theme.colors.primary }}>
            {Number(product.price || 0).toLocaleString('vi-VN')}₫
          </Text>
          <Chip
            compact
            style={{ backgroundColor: isLow ? '#f59e0b20' : '#10b98120' }}
            textStyle={{ color: isLow ? '#f59e0b' : '#10b981', fontWeight: '700', fontSize: 10 }}
          >
            {isLow ? 'Sắp hết' : `${product.stock} kho`}
          </Chip>
        </View>

        {product.category && (
          <Text variant="labelSmall" style={{ color: theme.colors.onSurfaceVariant, marginTop: 4 }}>
            📂 {product.category}
          </Text>
        )}
      </Card.Content>
    </Card>
  );
};

const ProductsScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const { list, loading } = useSelector((s) => s.products);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [modalVisible, setModalVisible] = useState(false);
  const [selected, setSelected] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [snack, setSnack] = useState('');

  const load = useCallback(() => { dispatch(fetchProducts({ search: debouncedSearch })); }, [dispatch, debouncedSearch]);
  useEffect(() => { load(); }, [load]);

  const filtered = search ? list.filter((p) => p.name?.toLowerCase().includes(search.toLowerCase())) : list;

  const handleSubmit = async (form) => {
    setSubmitting(true);
    try {
      let result;
      if (selected) result = await dispatch(updateProduct({ id: selected.id || selected._id, data: form }));
      else result = await dispatch(createProduct(form));
      if (!result.error) { setModalVisible(false); setSnack(selected ? 'Cập nhật thành công!' : 'Thêm sản phẩm thành công!'); load(); }
      else setSnack(result.payload || 'Có lỗi xảy ra');
    } finally { setSubmitting(false); }
  };

  const handleDelete = async () => {
    const result = await dispatch(deleteProduct(deleteTarget.id || deleteTarget._id));
    setDeleteTarget(null);
    setSnack(!result.error ? 'Đã xóa sản phẩm' : 'Xóa thất bại');
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Searchbar
        placeholder="Tìm sản phẩm..."
        value={search}
        onChangeText={setSearch}
        style={[styles.searchbar, { backgroundColor: theme.colors.surface }]}
        inputStyle={{ fontSize: 14 }}
      />

      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id || item._id)}
        numColumns={2}
        columnWrapperStyle={{ gap: 10 }}
        renderItem={({ item }) => (
          <View style={{ flex: 1 }}>
            <ProductCard product={item} onEdit={(p) => { setSelected(p); setModalVisible(true); }} onDelete={setDeleteTarget} />
          </View>
        )}
        contentContainerStyle={[styles.list, filtered.length === 0 && { flex: 1 }]}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} colors={[theme.colors.primary]} />}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListEmptyComponent={
          loading
            ? <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.primary} />
            : <EmptyState title="Chưa có sản phẩm" description="Nhấn + để thêm sản phẩm" />
        }
      />

      <FAB icon="plus" style={[styles.fab, { backgroundColor: theme.colors.primary }]} color="#fff" onPress={() => { setSelected(null); setModalVisible(true); }} />

      <ProductFormModal visible={modalVisible} onDismiss={() => setModalVisible(false)} onSubmit={handleSubmit} initial={selected} loading={submitting} />
      <ConfirmDialog visible={!!deleteTarget} title="Xóa sản phẩm" message={`Xóa sản phẩm "${deleteTarget?.name}"?`} onConfirm={handleDelete} onDismiss={() => setDeleteTarget(null)} />
      <Snackbar visible={!!snack} onDismiss={() => setSnack('')} duration={2500}>{snack}</Snackbar>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  searchbar: { margin: 12, borderRadius: 12, elevation: 0 },
  list: { paddingHorizontal: 12, paddingBottom: 80 },
  productCard: { borderRadius: 14, elevation: 1 },
  productHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  productIcon: { width: 48, height: 48, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  productActions: { flexDirection: 'row' },
  productFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  modal: { margin: 16, borderRadius: 20, padding: 24 },
  input: { marginBottom: 12 },
  catRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  catChip: { borderRadius: 8 },
  modalActions: { flexDirection: 'row', gap: 8 },
  fab: { position: 'absolute', right: 16, bottom: 16 },
});

export default ProductsScreen;
