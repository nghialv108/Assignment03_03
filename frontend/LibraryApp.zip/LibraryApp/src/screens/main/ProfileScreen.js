import React, { useState } from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import { Text, Card, Avatar, Chip, TextInput, Button, useTheme, Snackbar, Divider, Switch } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { authAPI } from '../../api/authAPI';
import { fetchProfile, logout } from '../../features/auth/authSlice';
import { useAppTheme } from '../../hooks/useAppTheme';

const ProfileScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const { user } = useSelector((s) => s.auth);
  const { darkMode, toggle: toggleDark } = useAppTheme();

  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [loading, setLoading] = useState(false);
  const [snack, setSnack] = useState('');

  const initial = (user?.name || user?.username || 'U')[0].toUpperCase();

  const handleUpdateInfo = async () => {
    setLoading(true);
    try {
      await authAPI.updateProfile({ name, email });
      await dispatch(fetchProfile());
      setSnack('Cập nhật thông tin thành công!');
    } catch (err) {
      setSnack(err.response?.data?.message || 'Cập nhật thất bại');
    } finally { setLoading(false); }
  };

  const handleChangePassword = async () => {
    if (newPwd !== confirmPwd) { setSnack('Mật khẩu xác nhận không khớp'); return; }
    setLoading(true);
    try {
      await authAPI.changePassword({ currentPassword: currentPwd, newPassword: newPwd });
      setSnack('Đổi mật khẩu thành công!');
      setCurrentPwd(''); setNewPwd(''); setConfirmPwd('');
    } catch (err) {
      setSnack(err.response?.data?.message || 'Đổi mật khẩu thất bại');
    } finally { setLoading(false); }
  };

  const handleLogout = () => dispatch(logout());

  return (
    <ScrollView style={{ backgroundColor: theme.colors.background }} contentContainerStyle={styles.container}>
      {/* Avatar card */}
      <Card style={[styles.card, { backgroundColor: theme.colors.surface }]}>
        <Card.Content style={styles.avatarSection}>
          <Avatar.Text size={80} label={initial} style={{ backgroundColor: '#6366f1' }} labelStyle={{ fontSize: 32, fontWeight: '800' }} />
          <Text variant="titleLarge" style={{ fontWeight: '800', marginTop: 12, color: theme.colors.onSurface }}>
            {user?.name || user?.username}
          </Text>
          <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>{user?.email}</Text>
          <Chip
            style={{ marginTop: 8, backgroundColor: '#6366f120' }}
            textStyle={{ color: '#6366f1', fontWeight: '700' }}
          >
            {user?.role || 'user'}
          </Chip>
        </Card.Content>
      </Card>

      {/* Dark mode toggle */}
      <Card style={[styles.card, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <View style={styles.settingRow}>
            <View>
              <Text variant="titleSmall" style={{ fontWeight: '600', color: theme.colors.onSurface }}>Chế độ tối</Text>
              <Text variant="bodySmall" style={{ color: theme.colors.onSurfaceVariant }}>Lưu tự động vào bộ nhớ</Text>
            </View>
            <Switch value={darkMode} onValueChange={toggleDark} color={theme.colors.primary} />
          </View>
        </Card.Content>
      </Card>

      {/* Update info */}
      <Card style={[styles.card, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text variant="titleMedium" style={{ fontWeight: '700', marginBottom: 16 }}>Thông tin cá nhân</Text>
          <TextInput label="Họ và tên" value={name} onChangeText={setName} mode="outlined" style={styles.input} left={<TextInput.Icon icon="account" />} />
          <TextInput label="Email" value={email} onChangeText={setEmail} mode="outlined" keyboardType="email-address" style={styles.input} left={<TextInput.Icon icon="email" />} />
          <Button mode="contained" onPress={handleUpdateInfo} loading={loading} style={{ borderRadius: 12 }}>
            Lưu thay đổi
          </Button>
        </Card.Content>
      </Card>

      {/* Change password */}
      <Card style={[styles.card, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text variant="titleMedium" style={{ fontWeight: '700', marginBottom: 16 }}>Đổi mật khẩu</Text>
          <TextInput label="Mật khẩu hiện tại" value={currentPwd} onChangeText={setCurrentPwd} secureTextEntry mode="outlined" style={styles.input} left={<TextInput.Icon icon="lock" />} />
          <TextInput label="Mật khẩu mới" value={newPwd} onChangeText={setNewPwd} secureTextEntry mode="outlined" style={styles.input} left={<TextInput.Icon icon="lock-plus" />} />
          <TextInput label="Xác nhận mật khẩu mới" value={confirmPwd} onChangeText={setConfirmPwd} secureTextEntry mode="outlined" style={styles.input} left={<TextInput.Icon icon="lock-check" />} />
          <Button mode="contained" onPress={handleChangePassword} loading={loading} style={{ borderRadius: 12, backgroundColor: '#f43f5e' }}>
            Đổi mật khẩu
          </Button>
        </Card.Content>
      </Card>

      {/* Logout */}
      <Button
        mode="outlined"
        onPress={handleLogout}
        style={[styles.logoutBtn, { borderColor: '#ef4444' }]}
        textColor="#ef4444"
        icon="logout"
      >
        Đăng xuất
      </Button>

      <Snackbar visible={!!snack} onDismiss={() => setSnack('')} duration={2500}>{snack}</Snackbar>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, paddingBottom: 40 },
  card: { borderRadius: 16, marginBottom: 14, elevation: 1 },
  avatarSection: { alignItems: 'center', paddingVertical: 8 },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  input: { marginBottom: 12 },
  logoutBtn: { borderRadius: 12, marginTop: 4 },
});

export default ProfileScreen;
