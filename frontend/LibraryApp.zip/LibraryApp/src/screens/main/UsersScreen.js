import React, { useEffect, useState, useCallback } from 'react';
import {
  View, FlatList, StyleSheet, TouchableOpacity, RefreshControl,
} from 'react-native';
import {
  Text, Searchbar, FAB, Card, Avatar, Chip, IconButton,
  useTheme, ActivityIndicator, Portal, Modal, TextInput, Button,
  Snackbar, Divider,
} from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers, createUser, updateUser, deleteUser } from '../../features/users/usersSlice';
import { useDebounce } from '../../hooks/useDebounce';
import EmptyState from '../../components/common/EmptyState';
import ConfirmDialog from '../../components/common/ConfirmDialog';

const ROLE_COLORS = { admin: '#ef4444', manager: '#f59e0b', user: '#6366f1' };

const defaultForm = { name: '', email: '', password: '', role: 'user' };

const UserFormModal = ({ visible, onDismiss, onSubmit, initial, loading }) => {
  const theme = useTheme();
  const isEdit = !!initial;
  const [form, setForm] = useState(defaultForm);
  const [showPass, setShowPass] = useState(false);

  useEffect(() => {
    setForm(initial ? { name: initial.name || '', email: initial.email || '', password: '', role: initial.role || 'user' } : defaultForm);
  }, [initial, visible]);

  const set = (k) => (v) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={[styles.modal, { backgroundColor: theme.colors.surface }]}>
        <Text variant="titleLarge" style={{ fontWeight: '700', marginBottom: 16 }}>
          {isEdit ? 'Cập nhật người dùng' : 'Thêm người dùng'}
        </Text>

        <TextInput label="Họ và tên" value={form.name} onChangeText={set('name')} mode="outlined" style={styles.input} left={<TextInput.Icon icon="account" />} />
        <TextInput label="Email" value={form.email} onChangeText={set('email')} mode="outlined" keyboardType="email-address" autoCapitalize="none" style={styles.input} left={<TextInput.Icon icon="email" />} />
        <TextInput
          label={isEdit ? 'Mật khẩu mới (bỏ trống nếu không đổi)' : 'Mật khẩu'}
          value={form.password} onChangeText={set('password')} secureTextEntry={!showPass} mode="outlined" style={styles.input}
          left={<TextInput.Icon icon="lock" />}
          right={<TextInput.Icon icon={showPass ? 'eye-off' : 'eye'} onPress={() => setShowPass(!showPass)} />}
        />

        <Text variant="labelMedium" style={{ color: theme.colors.onSurfaceVariant, marginBottom: 6 }}>Vai trò</Text>
        <View style={styles.roleRow}>
          {['user', 'manager', 'admin'].map((r) => (
            <Chip
              key={r} selected={form.role === r} onPress={() => set('role')(r)}
              style={[styles.roleChip, form.role === r && { backgroundColor: ROLE_COLORS[r] + '20' }]}
              selectedColor={ROLE_COLORS[r]}
            >
              {r}
            </Chip>
          ))}
        </View>

        <View style={styles.modalActions}>
          <Button onPress={onDismiss} textColor={theme.colors.onSurfaceVariant} style={{ flex: 1 }}>Hủy</Button>
          <Button mode="contained" onPress={() => onSubmit(form)} loading={loading} disabled={loading} style={{ flex: 1, borderRadius: 12 }}>
            {isEdit ? 'Cập nhật' : 'Thêm mới'}
          </Button>
        </View>
      </Modal>
    </Portal>
  );
};

const UserCard = ({ user, onEdit, onDelete }) => {
  const theme = useTheme();
  const initials = (user.name || user.username || '?')[0].toUpperCase();
  const roleColor = ROLE_COLORS[user.role] || '#6366f1';

  return (
    <Card style={[styles.userCard, { backgroundColor: theme.colors.surface }]}>
      <Card.Content style={styles.cardContent}>
        <Avatar.Text size={44} label={initials} style={{ backgroundColor: roleColor + '30' }} labelStyle={{ color: roleColor, fontWeight: '800' }} />
        <View style={styles.userInfo}>
          <Text variant="titleSmall" style={{ fontWeight: '700', color: theme.colors.onSurface }}>{user.name || user.username}</Text>
          <Text variant="bodySmall" style={{ color: theme.colors.onSurfaceVariant }}>{user.email}</Text>
          <Chip compact style={{ marginTop: 4, alignSelf: 'flex-start', backgroundColor: roleColor + '20' }} textStyle={{ color: roleColor, fontWeight: '700', fontSize: 10 }}>
            {user.role || 'user'}
          </Chip>
        </View>
        <View style={styles.cardActions}>
          <IconButton icon="pencil" size={18} iconColor={theme.colors.primary} onPress={() => onEdit(user)} />
          <IconButton icon="delete" size={18} iconColor="#ef4444" onPress={() => onDelete(user)} />
        </View>
      </Card.Content>
    </Card>
  );
};

const UsersScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const { list, loading } = useSelector((s) => s.users);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [modalVisible, setModalVisible] = useState(false);
  const [selected, setSelected] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [snack, setSnack] = useState('');

  const load = useCallback(() => {
    dispatch(fetchUsers({ search: debouncedSearch }));
  }, [dispatch, debouncedSearch]);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (form) => {
    setSubmitting(true);
    try {
      let result;
      if (selected) {
        const data = { ...form };
        if (!data.password) delete data.password;
        result = await dispatch(updateUser({ id: selected.id || selected._id, data }));
      } else {
        result = await dispatch(createUser(form));
      }
      if (!result.error) { setModalVisible(false); setSnack(selected ? 'Cập nhật thành công!' : 'Thêm người dùng thành công!'); load(); }
      else setSnack(result.payload || 'Có lỗi xảy ra');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    const result = await dispatch(deleteUser(deleteTarget.id || deleteTarget._id));
    setDeleteTarget(null);
    if (!result.error) setSnack('Đã xóa người dùng');
    else setSnack(result.payload || 'Xóa thất bại');
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Searchbar
        placeholder="Tìm kiếm người dùng..."
        value={search}
        onChangeText={setSearch}
        style={[styles.searchbar, { backgroundColor: theme.colors.surface }]}
        inputStyle={{ fontSize: 14 }}
      />

      <FlatList
        data={list}
        keyExtractor={(item) => String(item.id || item._id)}
        renderItem={({ item }) => (
          <UserCard user={item} onEdit={(u) => { setSelected(u); setModalVisible(true); }} onDelete={setDeleteTarget} />
        )}
        contentContainerStyle={[styles.list, list.length === 0 && { flex: 1 }]}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} colors={[theme.colors.primary]} />}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        ListEmptyComponent={
          loading ? (
            <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.primary} />
          ) : (
            <EmptyState title="Chưa có người dùng" description="Nhấn + để thêm người dùng mới" />
          )
        }
      />

      <FAB
        icon="plus"
        style={[styles.fab, { backgroundColor: theme.colors.primary }]}
        color="#fff"
        onPress={() => { setSelected(null); setModalVisible(true); }}
      />

      <UserFormModal
        visible={modalVisible}
        onDismiss={() => setModalVisible(false)}
        onSubmit={handleSubmit}
        initial={selected}
        loading={submitting}
      />

      <ConfirmDialog
        visible={!!deleteTarget}
        title="Xóa người dùng"
        message={`Bạn có chắc muốn xóa "${deleteTarget?.name || deleteTarget?.username}"?`}
        onConfirm={handleDelete}
        onDismiss={() => setDeleteTarget(null)}
      />

      <Snackbar visible={!!snack} onDismiss={() => setSnack('')} duration={2500}>
        {snack}
      </Snackbar>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  searchbar: { margin: 12, borderRadius: 12, elevation: 0 },
  list: { paddingHorizontal: 12, paddingBottom: 80 },
  userCard: { borderRadius: 14, elevation: 1 },
  cardContent: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  userInfo: { flex: 1 },
  cardActions: { flexDirection: 'row' },
  modal: { margin: 20, borderRadius: 20, padding: 24 },
  input: { marginBottom: 12 },
  roleRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  roleChip: { borderRadius: 8 },
  modalActions: { flexDirection: 'row', gap: 8 },
  fab: { position: 'absolute', right: 16, bottom: 16 },
});

export default UsersScreen;
