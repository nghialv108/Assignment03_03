export const colors = {
    background: 'rgba(0, 0, 0, 0.54)', // black@54
    surface: '#2C2C2C', // Màu nền cho các thẻ (Cards)
    primary: '#4CAF50', // Xanh lá cây (Nút bấm chính)
    text: '#FFFFFF',
    textSecondary: '#B0B0B0',
    danger: '#F44336'
};