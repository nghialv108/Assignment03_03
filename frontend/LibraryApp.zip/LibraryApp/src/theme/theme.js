import { MD3LightTheme, MD3DarkTheme } from 'react-native-paper';

const BASE_COLORS = {
  primary: '#6366f1',
  secondary: '#f43f5e',
  success: '#10b981',
  warning: '#f59e0b',
  info: '#3b82f6',
};

export const LightTheme = {
  ...MD3LightTheme,
  colors: {
    ...MD3LightTheme.colors,
    primary: BASE_COLORS.primary,
    secondary: BASE_COLORS.secondary,
    background: '#f8fafc',
    surface: '#ffffff',
    surfaceVariant: '#f1f5f9',
    onSurface: '#0f172a',
    onSurfaceVariant: '#64748b',
    outline: '#e2e8f0',
    error: '#ef4444',
  },
  custom: BASE_COLORS,
};

export const DarkTheme = {
  ...MD3DarkTheme,
  colors: {
    ...MD3DarkTheme.colors,
    primary: BASE_COLORS.primary,
    secondary: BASE_COLORS.secondary,
    background: '#0f172a',
    surface: '#1e293b',
    surfaceVariant: '#334155',
    onSurface: '#f1f5f9',
    onSurfaceVariant: '#94a3b8',
    outline: '#334155',
    error: '#ef4444',
  },
  custom: BASE_COLORS,
};
